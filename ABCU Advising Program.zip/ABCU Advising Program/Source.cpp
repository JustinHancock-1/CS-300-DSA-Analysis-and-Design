// Justin Hancock
// ABCU Advising Program

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <fstream>
#include <algorithm>

using namespace std;

// to define the structure to hold course info
struct Course {
    string courseId;
    string courseName;
    vector<string> preRequisite;
};

// to define the internal structure for binary tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    Node() { // default constructor
        left = nullptr;
        right = nullptr;
    }
    // initialize course node
    Node(Course aCourse) : Node() {
        this->course = aCourse;
    }

};

// to define the class
// to provide methods to implement a binary search tree
class BinarySearchTree {

public:
    Node* root;
    BinarySearchTree();
    void Search(string courseId);
    void Insert(BinarySearchTree* tree, Node* node);
    void PrintCourse(Node* node);
};

// default constructor
BinarySearchTree::BinarySearchTree() {
    root = nullptr;
};

// to display the menu
void DisplayMenu() {
    cout << "1. Load Data Structure" << endl;
    cout << "2. Print Course List" << endl;
    cout << "3. Print Course" << endl;
    cout << "9. Exit" << endl << endl;
    cout << "What would you like to do?" << endl;
}

// to search for a course
void BinarySearchTree::Search(string courseId) {
    Node* currentNode = root;

    while (currentNode != nullptr) {
        if (currentNode->course.courseId == courseId) {
            // to print the courseId & courseName
            cout << currentNode->course.courseId << ", ";
            cout << currentNode->course.courseName;
            cout << endl;
            cout << "Prerequisites: ";
            // to print any prereqs
            for (string preRequisite : currentNode->course.preRequisite) {
                if (preRequisite == currentNode->course.preRequisite.back()) {

                    cout << preRequisite << endl;
                }
                else {
                    cout << preRequisite << ", ";
                }
            }

            return;
        }
        // to searche the left pointer
        else if (courseId < currentNode->course.courseId) {

            if (currentNode->left != nullptr) {
                currentNode = currentNode->left;
            }
        }
        // to searche the right pointer
        else {

            currentNode = currentNode->right;
        }
    }
    // to validate if the course is not on the list
    cout << "Course " << courseId << "not found. " << endl;
    return;
}

//  to insert the course from the file into the binary search tree
void BinarySearchTree::Insert(BinarySearchTree* tree, Node* node) {

    if (tree->root == nullptr) {
        tree->root = node;
    }
    else {
        Node* curr = tree->root;
        while (curr != nullptr) {

            if (node->course.courseId < curr->course.courseId) {
                if (curr->left == nullptr) {
                    curr->left = node;
                    curr = nullptr;
                }
                else {
                    curr = curr->left;
                }
            }
            else {

                if (curr->right == nullptr) {
                    curr->right = node;
                    curr = nullptr;
                }
                else {
                    curr = curr->right;
                }
            }

        }

    }
}

// to print the course list
void BinarySearchTree::PrintCourse(Node* node) {

    // to find each node and print tree in order
    if (node == nullptr) {
        return;
    }
    // to look at the furthest left node & print courseId & courseName & then look at the next node
    PrintCourse(node->left);
    cout << node->course.courseId << ", ";
    cout << node->course.courseName << endl;
    PrintCourse(node->right);
};

// to load the file and create the course list
void loadCourse(string filename, BinarySearchTree* bst) {
    ifstream file(filename);
    if (file.is_open()) {
        cout << "File loaded." << endl;

        int num;
        string line;
        string word;

        while (getline(file, line)) {

            num = 0;
            Node* node = new Node();
            stringstream str(line);

            while (num < 2) {
                getline(str, word, ',');
                if (num == 0) {
                    node->course.courseId = word;
                }
                else {
                    node->course.courseName = word;
                }
                num++;
            }
            while (getline(str, word, ',')) {
                node->course.preRequisite.push_back(word);
            }

            // to insert node into binary search tree
            bst->Insert(bst, node);
        }
    }
    // to validate when the is a file error if the file is not found
    else {
        cout << "File error, please try again. " << endl;
        return;
    }

}

void main() {

    BinarySearchTree* bst = new BinarySearchTree();

    string fileChoice;
    string courseChoice;

    int userInput = 0;

    cout << "Welcome to the course planner." << endl;

    // while loop to keep program open while choice is not to exit
    while (userInput != 9) {
        DisplayMenu();
        cin >> userInput;

        switch (userInput) {
            // to call loadCourse file function 
        case 1:
            cout << endl;
            fileChoice = "Courses.csv";

            loadCourse(fileChoice, bst);
            cout << endl;
            break;

            // to call printCourse function
        case 2: 
            cout << "Here is the sample schedule:" << endl;
            cout << endl;
            bst->PrintCourse(bst->root);
            cout << endl;
            break;

            // to call Search function
        case 3:
            cout << endl;
            cout << "What course do you want to know about?";
            cin >> courseChoice;
            cout << endl;

            std::transform(courseChoice.begin(), courseChoice.end(), courseChoice.begin(), ::toupper);
            bst->Search(courseChoice);

            cout << endl;
            break;

            // to exit the program
        case 9:
            cout << "Thank you for using the course planner!" << endl;
            break;

            // to validate for an accurate input number
        default:
            cout << userInput << " is not a valid option." << endl << endl;
            break;
        }
    }
}